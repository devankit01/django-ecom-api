from django.apps import AppConfig


class EcomapiConfig(AppConfig):
    name = 'EcomAPI'
